#!/bin/bash
sudo yum install epel-next-release
sudo yum install ansible
