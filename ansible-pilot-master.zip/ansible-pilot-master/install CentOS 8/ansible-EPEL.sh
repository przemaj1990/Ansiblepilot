#!/bin/bash
sudo yum install epel-release
sudo yum install ansible
