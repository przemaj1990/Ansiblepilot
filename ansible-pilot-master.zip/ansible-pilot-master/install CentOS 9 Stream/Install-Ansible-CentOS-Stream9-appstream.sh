#!/bin/bash
sudo dnf update
sudo dnf install ansible-core

