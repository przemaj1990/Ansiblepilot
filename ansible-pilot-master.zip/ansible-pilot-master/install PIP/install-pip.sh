#!/bin/bash

python3 -m pip install --upgrade --user pip
python3 -m pip install --user ansible
