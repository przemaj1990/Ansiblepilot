#!/bin/bash
sudo dnf install epel-release
sudo dnf install ansible
ansible --version
