
wsl --update

wsl --set-default-version 1

wsl --list -o

wsl --install -d Ubuntu

