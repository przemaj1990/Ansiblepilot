
https://docs.microsoft.com/en-us/windows/wsl/install

wsl --help

wsl --list -o

wsl --install


